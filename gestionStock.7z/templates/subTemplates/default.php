<h1>Gestion Client</h1>
<?php

include __DIR__.DIRECTORY_SEPARATOR.'clientForm.php';

include __DIR__.DIRECTORY_SEPARATOR.'clientList.php';
