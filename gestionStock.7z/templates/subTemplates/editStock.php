<h1><?php echo htmlentities($title);?></h1>
<?php

include __DIR__.DIRECTORY_SEPARATOR.'stockForm.php';