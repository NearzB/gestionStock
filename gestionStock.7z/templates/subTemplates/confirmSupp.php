<h1>Confirmation suppresion</h1>
<?php
/**
 *
 *  @var \gestionStock\entities\Client $client
 */
?>
<form action="index.php?action=delete" method="post">
    <p>Voulez-vous réellement supprimer ce client: <?php echo htmlentities($client->getNomClient().' '.$client->getId());?> ?</p>
    <p><input type="hidden" name="client_id" value="<?php echo htmlentities($client->getId(), ENT_QUOTES);?>"/></p>
    <p class="submit-container"><input type="submit" value="OK"/></p>
</form>