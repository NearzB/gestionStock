<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?php echo $title ?></title>


</head>
<body>

<?php
if(isset($error))
{
    echo '<div class="erreur">'.htmlentities($error).'</div>';
}
$errorMessageList = \gestionStock\utils\ErrorMessageManager::getInstance()->getMessageList();

foreach ($errorMessageList as $error)
{
    echo '<div class="erreur">'.htmlentities($error).'</div>';
}

?>

<?php
$fileToIncludePath = __DIR__.DIRECTORY_SEPARATOR.'subTemplates'.DIRECTORY_SEPARATOR.$templateName;
if(file_exists($fileToIncludePath))
{
    include $fileToIncludePath;
}


?>
</body>
</html>