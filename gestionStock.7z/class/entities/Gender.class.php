<?php
/**
 * Created by PhpStorm.
 * User: selim
 * Date: 26/04/2017
 * Time: 18:14
 */

namespace gestionStock\entities;


class Gender
{
    /**
     * @var string
     */
    const M = "M";
    /**
     * @var string
     */
    const F = "F";


    private function __controller()
    {}


}
