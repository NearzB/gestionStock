<?php
/**
 * Created by PhpStorm.
 * User: Unknown
 * Date: 14/06/2017
 * Time: 19:40
 */

namespace gestionStock\entities;


class Fournisseur
{

    /**
     * @var int
     */
    private $idFournisseur;
    /**
     * @var string
     */
    private $nomFournissseur;
    /**
     * @var string
     */
    private $numeroCompte;
    /**
     * @var int
     */
    private $numeroTel;
    /**
     * @var string
     */
    private $numeroTVA;
    /**
     * @var string
     */
    private $adresseFournisseur;
    /**
     * @var string date
     */
    private $dateAjout;











    /**
     * @return int
     */
    public function getIdFournisseur()
    {
        return $this->idFournisseur;
    }

    /**
     * @param int $idFournisseur
     */
    public function setIdFournisseur($idFournisseur)
    {

        $this->idFournisseur = (int)$idFournisseur;
        if($this->idFournisseur === 0)
            $this->idFournisseur = null;
    }




    /**
     * @return string
     */
    public function getNomFournissseur()
    {
        return $this->nomFournissseur;
    }

    /**
     * @param string $nomFournissseur
     */
    public function setNomFournissseur($nomFournissseur)
    {
        $this->nomFournissseur = $nomFournissseur;
    }


    /**
     * @return string
     */
    public function getNumeroCompte()
    {
        return $this->numeroCompte;
    }

    /**
     * @param string $numeroCompte
     */
    public function setNumeroCompte($numeroCompte)
    {
        $this->numeroCompte = $numeroCompte;
    }



    /**
     * @return int
     */
    public function getNumeroTel()
    {
        return $this->numeroTel;
    }

    /**
     * @param int $numeroTel
     */
    public function setNumeroTel($numeroTel)
    {
        $this->numeroTel = $numeroTel;
    }




    /**
     * @return string
     */
    public function getNumeroTVA()
    {
        return $this->numeroTVA;
    }

    /**
     * @param string $numeroTVA
     */
    public function setNumeroTVA($numeroTVA)
    {
        $this->numeroTVA = $numeroTVA;
    }




    /**
     * @return string
     */
    public function getAdresseFournisseur()
    {
        return $this->adresseFournisseur;
    }

    /**
     * @param string $numeroTVA
     */
    public function setAdresseFournisseur($adresseFournisseur)
    {
        $this->adresseFournisseur = $adresseFournisseur;
    }

    /**
     * @return string date
     */
    public function getDateAjout()
    {
        return $this->dateAjout;
    }

    /**
     * @param string date $dateAjout
     */
    public function setDateAjout($dateAjout)
    {
        $this->dateAjout = $dateAjout;
    }

}