<?php
namespace gestionStock\controllers;


interface IController
{

    public function doAction();

}