<?php
namespace gestionStock\views;


class EditClientView extends AView implements IView
{


    protected  function getTemplateNameWithoutExt()
    {
        return 'editClient';
    }

    protected  function getTitle()
    {
        return "Modifier client";
    }

}