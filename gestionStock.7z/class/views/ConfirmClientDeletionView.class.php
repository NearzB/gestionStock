<?php
namespace gestionStock\views;


class ConfirmClientDeletionView extends AView implements IView
{


    protected  function getTemplateNameWithoutExt()
    {
        return 'confirmSupp';
    }

    protected  function getTitle()
    {
        return "Confirm deletion";
    }

}