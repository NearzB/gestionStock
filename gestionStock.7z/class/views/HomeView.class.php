<?php
namespace gestionStock\views;


class HomeView extends AView implements IView
{

    protected  function getTemplateNameWithoutExt()
    {
        return 'default';
    }

    protected  function getTitle()
    {
        return "Home page";
    }

}