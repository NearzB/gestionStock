<?php
/**
 * Created by PhpStorm.
 * User: Unknown
 * Date: 28/06/2017
 * Time: 21:47
 */

namespace gestionStock\views;


class CreateStockView extends AView implements IView
{


    protected  function getTemplateNameWithoutExt()
    {
        return 'editStock';
    }

    protected  function getTitle()
    {
        return "Create stock";
    }

}
