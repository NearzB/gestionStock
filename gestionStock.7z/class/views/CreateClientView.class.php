<?php
namespace gestionStock\views;


class CreateClientView extends AView implements IView
{


    protected  function getTemplateNameWithoutExt()
    {
        return 'editClient';
    }

    protected  function getTitle()
    {
        return "Create client";
    }

}