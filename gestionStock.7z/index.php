<?php
session_start();
require_once __DIR__.DIRECTORY_SEPARATOR.'class'.DIRECTORY_SEPARATOR.'autoloader.php';

if(!isset($_GET['action']))
{
    $controller = new \gestionStock\controllers\HomeController();
}
else if($_GET['action'] == 'create')
{
    $controller = new \gestionStock\controllers\DeleteClientController();
}
else if($_GET['action'] == 'edit')
{
    $controller = new \gestionStock\controllers\EditClientController();
}
else if($_GET['action'] == 'delete')
{
    $controller = new \gestionStock\controllers\DeleteClientController();
}
else
{
    $controller = new \gestionStock\controllers\NotFoundController();
}

$controller->doAction();